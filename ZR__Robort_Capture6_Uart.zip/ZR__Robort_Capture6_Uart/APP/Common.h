//***************************************ͷ�ļ�������***********************************************
#include "stm32f10x.h"
#include <stdio.h>
#include "BSP_Led.h"
#include "BSP_Timer.h"
#include "BSP_Systick.h"
#include "BSP_Uart.h"
#include "BSP_Pwm.h"
#include "BSP_Pantilt.h"
#include "BSP_ADC.h"

#include "BSP_IIC.h"




//***************************************�������Ͷ��� ***********************************************
#define uchar unsigned char
#define uint  unsigned int
#define ulong unsigned long





