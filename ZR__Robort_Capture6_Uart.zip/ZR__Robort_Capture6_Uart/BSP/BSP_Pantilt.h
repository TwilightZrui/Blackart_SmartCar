void H_ACT_Ctrl(unsigned char Angle);



extern unsigned char Horizontal_Angle; //��̨ˮƽ�Ƕ�
extern unsigned char Vertical_Angle;   //��̨��ֱ�Ƕ�
























/*********************************************END OF FILE**********************/
